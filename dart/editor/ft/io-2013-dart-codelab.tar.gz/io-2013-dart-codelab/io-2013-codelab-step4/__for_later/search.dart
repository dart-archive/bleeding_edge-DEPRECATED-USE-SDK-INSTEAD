// STEP 4: Add this library to enable searching.

/**
 * A library for searching and filtering documents.
 */
library search;

import 'package:web_ui/web_ui.dart';

import 'package:writer/document.dart';

// STEP 4: Add an observed string to filter documents.


// STEP 4: Add function to check if a document matches the search filter.

