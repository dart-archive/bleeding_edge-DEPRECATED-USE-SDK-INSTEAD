#!/usr/bin/env dart

import 'package:web_ui/component_build.dart';
import 'dart:async';

void main(List<String> args) {
  build(args, ['web/index.html'])
    .then((_) => print('Build finished!'));
}
